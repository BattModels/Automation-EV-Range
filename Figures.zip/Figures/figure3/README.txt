Sheet Figure 3(a) is for the composite profile box plot.

Columns 1-2 are the Tesla Model 3 with and without LiDAR respectively.

Columns 3-4 are the Tesla Model S with and without LiDAR respectively.

Columns 5-6 are the Chevy Bolt with and without LiDAR respectively.

Columns 7-8 are the Nissan Leaf with and without LiDAR respectively.

Columns 9-10 are the Xpeng G3 with and without LiDAR respectively.



Sheet Figure 3(b) is for the city profile box plot.

Columns 1-2 are the Tesla Model 3 with and without LiDAR respectively.

Columns 3-4 are the Tesla Model S with and without LiDAR respectively.

Columns 5-6 are the Chevy Bolt with and without LiDAR respectively.

Columns 7-8 are the Nissan Leaf with and without LiDAR respectively.

Columns 9-10 are the Xpeng G3 with and without LiDAR respectively.



We have provided the MATLAB file to generate the box plots. Outlier data is marked with a red +. Maximum whisker length is 1.5 times the interquartile range.